//bikin Array
const keluarga = ["Rahman", "Laili", "Ziyad"];

//method foreach : fungsi didalam fungsi
keluarga.forEach(function (nama) {
    console.log(`Nama : ${nama}`);
});
