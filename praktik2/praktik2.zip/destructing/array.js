//Buat Array
const keluarga = ["Rahman", "Laili", "Ziyad"];

// Simpen array ke variabel masing2
const [ayah, ibu, anak] = keluarga;

//tampilin
console.log(ayah, ibu, anak);
