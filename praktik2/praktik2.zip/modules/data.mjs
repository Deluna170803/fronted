//membuat array of object
const users = [
    { name: "Jonas", age: 15 },
    { name: "Michael", age: 40 },
    { name: "Hannah", age: 35 },
];

//kirim data
export default users;