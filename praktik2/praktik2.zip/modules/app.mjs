import { index, store } from "./controller.mjs";
